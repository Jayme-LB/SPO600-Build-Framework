
// vim:sw=2:ai

/*
 * Copyright (C) 2010-2011 DeNA Co.,Ltd.. All rights reserved.
 * Copyright (C) 2011 Kentoku SHIBA
 * See COPYRIGHT.txt for details.
 */

#ifndef DENA_FATAL_HPP
#define DENA_FATAL_HPP

#include "mysql_version.h"
#if MYSQL_VERSION_ID < 50500
#include "mysql_priv.h"
#include <mysql/plugin.h>
#else
#include "sql_priv.h"
#include "probes_mysql.h"
#include "sql_class.h"
#endif

namespace dena {

void fatal_exit(const String& message);
void fatal_exit(const char *message);
void fatal_abort(const String& message);
void fatal_abort(const char *message);

};

#endif

