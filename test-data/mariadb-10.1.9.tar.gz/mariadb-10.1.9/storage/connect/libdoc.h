#ifndef LIBDOC_H_INCLUDED
#define LIBDOC_H_INCLUDED
void XmlInitParserLib(void);
void XmlCleanupParserLib(void);
void CloseXML2File(PGLOBAL, PFBLOCK, bool);
#endif
