/**************************************************************************/
/*  NLS messsages definition.                                             */
/**************************************************************************/
#if defined(FRENCH)
#if defined(CPX)
#include "frmsg1.h"
#else   /* not CPX */
#include "frmsg2.h"
#endif  /* CPX */
#else   /* not FRENCH */
#include "engmsg.h"
#endif  /* FRENCH */
/* ---------------------------------------------------------------------- */
