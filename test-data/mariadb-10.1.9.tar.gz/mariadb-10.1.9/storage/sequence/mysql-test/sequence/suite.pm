package My::Suite::Sequence;
@ISA = qw(My::Suite);

sub is_default { 1 }

bless { };

